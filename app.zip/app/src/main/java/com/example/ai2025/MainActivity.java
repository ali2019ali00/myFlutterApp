package com.example.ai_2025;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    EditText inputDescription;
    Button btnGenerate;
    ImageView imageResult;
    RadioGroup styleGroup;

    String apiKey = "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";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputDescription = findViewById(R.id.inputDescription);
        btnGenerate = findViewById(R.id.btnGenerate);
        imageResult = findViewById(R.id.imageResult);
        styleGroup = findViewById(R.id.styleGroup);

        btnGenerate.setOnClickListener(v -> {
            String prompt = inputDescription.getText().toString().trim();
            if (!prompt.isEmpty()) {
                String style = getSelectedStyle();
                new GenerateImageTask().execute(prompt + " style: " + style);
            } else {
                Toast.makeText(this, "يرجى كتابة وصف للصورة", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String getSelectedStyle() {
        int checkedId = styleGroup.getCheckedRadioButtonId();
        if (checkedId == R.id.styleAnime) return "anime";
        if (checkedId == R.id.styleReal) return "realistic";
        if (checkedId == R.id.styleNeon) return "neon";
        if (checkedId == R.id.styleSketch) return "sketch";
        return "";
    }

    class GenerateImageTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... prompts) {
            try {
                URL url = new URL("https://api.openai.com/v1/images/generations");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Authorization", "Bearer " + apiKey);
                conn.setDoOutput(true);

                JSONObject json = new JSONObject();
                json.put("prompt", prompts[0]);
                json.put("n", 1);
                json.put("size", "512x512");

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = json.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    response.append(line.trim());
                }

                JSONObject jsonResponse = new JSONObject(response.toString());
                return jsonResponse.getJSONArray("data").getJSONObject(0).getString("url");

            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String imageUrl) {
            if (imageUrl != null) {
                new DownloadImageTask(imageResult).execute(imageUrl);
            } else {
                Toast.makeText(MainActivity.this, "فشل في توليد الصورة", Toast.LENGTH_SHORT).show();
            }
        }
    }
}